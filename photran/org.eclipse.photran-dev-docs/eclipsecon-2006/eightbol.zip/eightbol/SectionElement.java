package org.eightbol.modelbuilder;

import org.eclipse.cdt.core.addl_langs.IAdditionalLanguageElement;
import org.eclipse.cdt.core.model.ICElement;
import org.eclipse.cdt.core.model.IParent;
import org.eclipse.cdt.core.model.ISourceReference;
import org.eclipse.cdt.internal.core.model.SourceManipulation;
import org.eightbol.EightbolPlugin;

public class SectionElement
	extends SourceManipulation
	implements ICElement, IParent, ISourceReference, IAdditionalLanguageElement
{
	public SectionElement(ICElement parent, String name, int offset, int length, int startLine, int endLine)
	{
		super(parent, name, -1);
		
		setIdPos(offset, length);
		setPos(offset, length);
		setLines(startLine, endLine);
	}

	public Object getBaseImageDescriptor()
	{
		return EightbolPlugin.getImageDescriptor("icons/sample.gif");
	}
}
