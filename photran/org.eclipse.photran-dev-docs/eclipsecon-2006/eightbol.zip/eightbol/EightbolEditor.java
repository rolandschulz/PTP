package org.eightbol.editor;

import org.eclipse.cdt.core.model.CModelException;
import org.eclipse.cdt.core.model.ISourceRange;
import org.eclipse.cdt.core.model.ISourceReference;
import org.eclipse.cdt.internal.ui.editor.CContentOutlinePage;
import org.eclipse.cdt.internal.ui.editor.CTextEditorActionConstants;
import org.eclipse.cdt.ui.CUIPlugin;
import org.eclipse.cdt.ui.IWorkingCopyManager;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.rules.FastPartitioner;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPartService;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.editors.text.TextEditor;
import org.eclipse.ui.part.IShowInTargetList;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;

public class EightbolEditor extends TextEditor implements ISelectionChangedListener {

	private ColorManager colorManager;

	public EightbolEditor() {
		super();
		colorManager = new ColorManager();
		setSourceViewerConfiguration(new XMLConfiguration(colorManager));
		//setDocumentProvider(new XMLDocumentProvider());
		setDocumentProvider(CUIPlugin.getDefault().getDocumentProvider());
		
		setRulerContextMenuId("#CEditorRulerContext");
	}
	public void dispose() {
		colorManager.dispose();
		super.dispose();
	}
	
	@Override
	protected void doSetInput(IEditorInput input) throws CoreException
	{
		super.doSetInput(input);
		IDocument document = this.getDocumentProvider().getDocument(input);
		
		if (document != null) {
			IDocumentPartitioner partitioner =
				new FastPartitioner(
					new XMLPartitionScanner(),
					new String[] {
						XMLPartitionScanner.XML_TAG,
						XMLPartitionScanner.XML_COMMENT });
			partitioner.connect(document);
			document.setDocumentPartitioner(partitioner);
		}
	}

	protected CContentOutlinePage fOutlinePage;

	public Object getAdapter(Class required) {
	  if (IContentOutlinePage.class.equals(required)) {
	    return getOutlinePage();
	  }
	  if (required == IShowInTargetList.class) {
	    return new IShowInTargetList() {
	      public String[] getShowInTargetIds() {
	        return new String[] { CUIPlugin.CVIEW_ID,
	          IPageLayout.ID_OUTLINE,
	          IPageLayout.ID_RES_NAV };
	      }

	    };
	  }
	  return super.getAdapter(required);
	}

	public CContentOutlinePage getOutlinePage() {
	  if (fOutlinePage == null) {
	    // For now, at least, the editor parameter can be null
	    fOutlinePage = new CContentOutlinePage(null);
	    
	    // Remove the following line if you have not set up the
	    // editor to sync with the Outline view (i.e., the
	    // editor does not implement ISelectionChangedListener)
	    fOutlinePage.addSelectionChangedListener(this);
	  }
	  setOutlinePageInput(fOutlinePage, getEditorInput());
	  return fOutlinePage;
	}

	public static void setOutlinePageInput(
	    CContentOutlinePage page,
	    IEditorInput input) {
	  if (page != null) {
	    IWorkingCopyManager manager =
	      CUIPlugin.getDefault().getWorkingCopyManager();
	    page.setInput(manager.getWorkingCopy(input));
	  }
	}
	
	// --- FOR SYNCHRONIZING THE EDITOR AND OUTLINE VIEW ---
	
	public void selectionChanged(SelectionChangedEvent event) {
		ISelection sel = event.getSelection();
		if (sel instanceof IStructuredSelection) {
			IStructuredSelection selection = (IStructuredSelection) sel;
			Object obj = selection.getFirstElement();
			if (obj instanceof ISourceReference) {
				try {
					ISourceRange range = ((ISourceReference) obj)
							.getSourceRange();
					if (range != null) {
						setSelection(range, !isActivePart());
					}
				} catch (CModelException e) {
					// Selection change not applied.
				}
			}
		}
	}
	
	private boolean isActivePart() {
		IWorkbenchWindow window = getSite().getWorkbenchWindow();
		IPartService service = window.getPartService();
		return (this == service.getActivePart());
	}

	public void setSelection(ISourceRange element, boolean moveCursor) {
		
		if (element == null) {
			return;
		}
	
		try {
			IRegion alternateRegion = null;
			int start = element.getStartPos();
			int length = element.getLength();
	
			// Sanity check sometimes the parser may throw wrong numbers.
			if (start < 0 || length < 0) {
				start = 0;
				length = 0;
			}
	
			// 0 length and start and non-zero start line says we know
			// the line for some reason, but not the offset.
			if (length == 0 && start == 0 && element.getStartLine() > 0) {
				// We have the information in term of lines, we can work it out.
				// Binary elements return the first executable statement so we
				// have to substract -1
				start = getDocumentProvider().getDocument(getEditorInput())
						.getLineOffset(element.getStartLine() - 1);
				if (element.getEndLine() > 0) {
					length = getDocumentProvider()
							.getDocument(getEditorInput()).getLineOffset(
									element.getEndLine())
							- start;
				} else {
					length = start;
				}
				// create an alternate region for the keyword highlight.
				alternateRegion = getDocumentProvider().getDocument(
						getEditorInput()).getLineInformation(
						element.getStartLine() - 1);
				if (start == length || length < 0) {
					if (alternateRegion != null) {
						start = alternateRegion.getOffset();
						length = alternateRegion.getLength();
					}
				}
			}
			setHighlightRange(start, length, moveCursor);
	
			if (moveCursor) {
				start = element.getIdStartPos();
				length = element.getIdLength();
				if (start == 0 && length == 0 && alternateRegion != null) {
					start = alternateRegion.getOffset();
					length = alternateRegion.getLength();
				}
				if (start > -1 && getSourceViewer() != null) {
					getSourceViewer().revealRange(start, length);
					getSourceViewer().setSelectedRange(start, length);
				}
				updateStatusField(CTextEditorActionConstants.STATUS_CURSOR_POS);
			}
			return;
		} catch (IllegalArgumentException x) {
			// No information to the user
		} catch (BadLocationException e) {
			// No information to the user
		}
	
		if (moveCursor)
			resetHighlightRange();
	}
}
