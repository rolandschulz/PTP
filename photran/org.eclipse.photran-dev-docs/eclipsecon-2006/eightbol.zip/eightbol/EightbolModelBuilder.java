package org.eightbol.modelbuilder;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.SAXParserFactory;

import org.eclipse.cdt.core.addl_langs.IModelBuilder;
import org.eclipse.cdt.core.model.CModelException;
import org.eclipse.cdt.core.model.ICElement;
import org.eclipse.cdt.internal.core.model.CElementInfo;
import org.eclipse.cdt.internal.core.model.TranslationUnit;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * This is a model builder for Eightbol programs.  It is tied into the CDT via
 * the EightbolLanguage class.
 * 
 * This model builder uses SAX to identify <i>section</i> tags in an Eightbol
 * program and create <code>SectionElement</code>s for them.  Thus, the Outline
 * view for a file will list all of the sections defined in that file.
 */
public final class EightbolModelBuilder implements IModelBuilder
{
	protected static final String LINE_TERMINATOR = System.getProperty("line.separator");
	protected static final int LINE_TERMINATOR_LENGTH = LINE_TERMINATOR.length();

	protected TranslationUnit translationUnit;
	protected ArrayList<Integer> lineOffsets = new ArrayList<Integer>();
	
	public EightbolModelBuilder(TranslationUnit tu)
	{
		this.translationUnit = tu;
	}
	
	public Map<ICElement, CElementInfo> parse(boolean quickParseMode) throws Exception
	{
		translationUnit.removeChildren();
		boolean parseWasSuccessful = parseTranslationUnitIntoModel();
		translationUnit.getElementInfo().setIsStructureKnown(parseWasSuccessful);
		
		Map<ICElement, CElementInfo> modelElements = new HashMap<ICElement, CElementInfo>();
		modelElements.put(translationUnit, translationUnit.getElementInfo());
		return modelElements;
	}

	/**
	 * Runs an <code>EightbolModelBuildingParser</code> (defined below) to
	 * build the model.
	 * @return true iff the parse was successful
	 */
	protected boolean parseTranslationUnitIntoModel()
	{
		boolean wasSuccessful;
		try
		{
			String translationUnitText = translationUnit.getBuffer().getContents();
			determineLineOffsets(translationUnitText);
			
			InputStream in = new ByteArrayInputStream(translationUnitText.getBytes());
			EightbolModelBuildingParser parser = new EightbolModelBuildingParser();
			
			SAXParserFactory.newInstance().newSAXParser().parse(in, parser);
			wasSuccessful = true;
		}
		catch (Throwable e)
		{
			wasSuccessful = false;
		}
		return wasSuccessful;
	}

	/**
	 * Fills the <code>lineOffsets</code> vector such that the entry at index
	 * zero contains the offset of line 1, index 1 contains the offset of line
	 * 2, etc.
	 * @param text the full text of the translation unit for which the model
	 * is being built
	 */
	protected void determineLineOffsets(String text)
	{
		int terminatorOffset;
		int offsetOfFirstCharOnLine = 0;	// Line 1 has offset 0
		
		do
		{
			lineOffsets.add(offsetOfFirstCharOnLine);
			
			terminatorOffset = text.indexOf(LINE_TERMINATOR, offsetOfFirstCharOnLine);
			offsetOfFirstCharOnLine = terminatorOffset + LINE_TERMINATOR_LENGTH;
		}
		while (terminatorOffset >= 0);
	}

	/**
	 * Uses the <code>lineOffsets</code> vector to determine the character
	 * offset of a given line.  Expects that <code>determineLineOffsets</code>
	 * has already been called to set up the <code>lineOffsets</code> vector.
	 * @param lineNumber
	 * @return
	 */
	protected int getOffsetOfLine(int lineNumber)
	{
		int index = lineNumber - 1;
		
		if (index < lineOffsets.size())
			return lineOffsets.get(index);
		else
			return -1;
	}

	/**
	 * Locates &lt;section name=&quot;Something&quot;&gt; tags and adds model elements for each
	 * 
	 * According to the Eightbol grammar, sections can't be nested.  We assume that there are no
	 * nested sections here.  If that were the case, we would need to maintain a stack of
	 * SectionElements in order to remember which was the last parent (rather than our
	 * <code>lastSectionElement</code> field, which is kind of a cop-out).
	 */
	protected class EightbolModelBuildingParser extends DefaultHandler
	{
		protected Locator locator = null;
		
		@Override
		public void setDocumentLocator(Locator locator) {
			this.locator = locator;
		}
		
		@Override
		public void startElement(String uri,
				                 String localName,
				                 String qName,
				                 Attributes attributes)
			throws SAXException
	    {
			if (qName.equals("section"))
			{
				try
				{
					String sectionName = attributes.getValue("name");
					int lineNum = locator == null ? 0 : locator.getLineNumber();
					int offset = getOffsetOfLine(lineNum);
					int length = getOffsetOfLine(lineNum+1) - LINE_TERMINATOR_LENGTH - offset;
					
					translationUnit.addChild(new SectionElement(translationUnit, sectionName, offset, length, lineNum, lineNum));
				}
				catch (CModelException e)
				{
					throw new Error(e);
				}
			}
		}
	}
}
